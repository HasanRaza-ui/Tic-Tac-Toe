/*
 * CConsoleIO.cpp
 *
 *  Created on: Nov 16, 2023
 *      Author: hasan.raza@stud.h-da.de
 */
#include"CConsoleIO.h"


void CConsoleIO::displayMessage(const string& message){
	cout << "\n";
	cout << message << endl;
}


